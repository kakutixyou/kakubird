import * as React from "react";

export type BuildStatus = "pending" | "building" | "success" | "warning" | "error";

export interface BuildStep {
  name: string;
  status: BuildStatus | string;
  message?: string | null;
  progress_percent?: number;
  started_at?: string | null;
  finished_at?: string | null;
  duration_ms?: number | null;
}

export interface FeatureCheckItem {
  name: string;
  status: string;
  message?: string | null;
}

export interface FeatureCheck {
  key: string;
  title: string;
  status: string;
  summary?: string | null;
  checks: FeatureCheckItem[];
}

export interface GeneratedFileSummary {
  path: string;
  status: BuildStatus | string;
  source?: string | null;
  error?: string | null;
  characters?: number;
}

export interface ValidationIssue {
  level?: string;
  code?: string;
  message?: string;
  file_path?: string | null;
}

export interface ValidationResult {
  success?: boolean;
  status?: BuildStatus | string;
  message?: string;
  checked_files?: number;
  errors?: ValidationIssue[];
  warnings?: ValidationIssue[];
  logs?: string[];
}

export interface RepairAction {
  action?: string;
  file_path?: string | null;
  reason?: string;
  related_errors?: string[];
}

export interface RepairIteration {
  iteration?: number;
  actions?: RepairAction[];
  repaired_files?: string[];
  failed_files?: string[];
  validation_before?: ValidationResult | null;
  validation_after?: ValidationResult | null;
}

export interface RepairResult {
  success?: boolean;
  total_iterations?: number;
  iterations?: RepairIteration[];
  final_validation?: ValidationResult | null;
  error?: string | null;
}

export interface ProjectBuildData {
  project_name: string;
  status: BuildStatus | string;
  message: string;
  files_generated: number;
  project_root?: string | null;
  zip_path?: string | null;
  zip_download_url?: string | null;
  zip_files_added?: number;
  plan?: Record<string, unknown> | null;
  generation: GeneratedFileSummary[];
  write_result?: Record<string, unknown> | null;
  validation?: ValidationResult | null;
  repair?: RepairResult | null;
  steps: BuildStep[];
  logs: string[];
  errors: string[];
  warnings: string[];
  progress_percent: number;
  current_stage: string;
  elapsed_seconds: number;
  estimated_total_minutes?: number | null;
  estimated_remaining_minutes?: number | null;
  estimate_confidence: string;
  feature_checks: FeatureCheck[];
}

export interface ProjectBuildBlockProps {
  /** Current block renderer style: <ProjectBuildBlock data={block.data} /> */
  data?: unknown;
  /** Legacy block renderer style: <ProjectBuildBlock block={block} /> */
  block?: { data?: unknown } | null;
  /** Optional backend origin, for example http://localhost:8000. */
  apiBaseUrl?: string;
  className?: string;
  onDownload?: (url: string, data: ProjectBuildData) => void;
}

type UnknownRecord = Record<string, unknown>;

const STATUS_LABELS: Record<string, string> = {
  pending: "待機中",
  building: "生成中",
  success: "完了",
  warning: "警告あり",
  error: "失敗",
};

const STATUS_ICONS: Record<string, string> = {
  pending: "○",
  building: "◌",
  success: "✓",
  warning: "!",
  error: "×",
};

const ESTIMATE_CONFIDENCE_LABELS: Record<string, string> = {
  low: "低",
  medium: "中",
  high: "高",
};

const COLORS = {
  background: "#ffffff",
  border: "#d9e2ec",
  muted: "#5f6c7b",
  text: "#17212b",
  success: "#16794b",
  successSoft: "#e8f7ef",
  warning: "#946200",
  warningSoft: "#fff6d8",
  error: "#b42318",
  errorSoft: "#fff0ee",
  building: "#2463eb",
  buildingSoft: "#edf4ff",
  pending: "#6b7280",
  pendingSoft: "#f2f4f7",
} as const;

const styles: Record<string, React.CSSProperties> = {
  root: {
    width: "100%",
    boxSizing: "border-box",
    border: `1px solid ${COLORS.border}`,
    borderRadius: 16,
    background: COLORS.background,
    color: COLORS.text,
    boxShadow: "0 8px 28px rgba(30, 50, 70, 0.08)",
    overflow: "hidden",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  header: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 16,
    padding: "20px 22px 16px",
  },
  titleGroup: { minWidth: 0, flex: "1 1 280px" },
  eyebrow: {
    margin: "0 0 5px",
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: 700,
    letterSpacing: "0.08em",
    textTransform: "uppercase",
  },
  title: {
    margin: 0,
    overflowWrap: "anywhere",
    fontSize: 20,
    lineHeight: 1.35,
  },
  message: { margin: "7px 0 0", color: COLORS.muted, fontSize: 14, lineHeight: 1.6 },
  body: { padding: "0 22px 22px" },
  progressTrack: {
    height: 8,
    overflow: "hidden",
    borderRadius: 999,
    background: "#edf1f5",
  },
  summaryGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
    gap: 10,
    marginTop: 14,
  },
  summaryCard: {
    padding: "12px 14px",
    border: `1px solid ${COLORS.border}`,
    borderRadius: 11,
    background: "#fbfcfe",
  },
  summaryLabel: { color: COLORS.muted, fontSize: 12 },
  summaryValue: { display: "block", marginTop: 4, fontSize: 18, fontWeight: 750 },
  section: { marginTop: 18 },
  sectionTitle: { margin: "0 0 9px", fontSize: 14, fontWeight: 750 },
  stepList: { display: "grid", gap: 8, margin: 0, padding: 0, listStyle: "none" },
  step: {
    display: "grid",
    gridTemplateColumns: "30px minmax(0, 1fr)",
    gap: 10,
    alignItems: "start",
    padding: "10px 12px",
    border: `1px solid ${COLORS.border}`,
    borderRadius: 10,
  },
  stepName: { fontSize: 14, fontWeight: 700, overflowWrap: "anywhere" },
  stepMessage: { marginTop: 3, color: COLORS.muted, fontSize: 12, lineHeight: 1.5 },
  list: { margin: 0, paddingLeft: 20, fontSize: 13, lineHeight: 1.65 },
  details: {
    marginTop: 10,
    border: `1px solid ${COLORS.border}`,
    borderRadius: 10,
    background: "#fbfcfe",
  },
  detailsSummary: { cursor: "pointer", padding: "11px 13px", fontSize: 13, fontWeight: 700 },
  detailsBody: { padding: "0 13px 13px" },
  codeList: {
    maxHeight: 240,
    overflow: "auto",
    margin: 0,
    padding: "10px 12px",
    borderRadius: 8,
    background: "#17212b",
    color: "#e7edf3",
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
    fontSize: 12,
    lineHeight: 1.6,
    whiteSpace: "pre-wrap",
    overflowWrap: "anywhere",
  },
  download: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    minHeight: 40,
    padding: "0 16px",
    borderRadius: 10,
    background: COLORS.building,
    color: "#fff",
    fontSize: 14,
    fontWeight: 750,
    textDecoration: "none",
  },
  notice: { margin: 0, padding: "10px 12px", borderRadius: 9, fontSize: 13, lineHeight: 1.55 },
};

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringValue(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : value == null ? fallback : String(value);
}

function numberValue(value: unknown, fallback = 0): number {
  const number = typeof value === "number" ? value : Number(value);
  return Number.isFinite(number) && number >= 0 ? number : fallback;
}

function stringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => stringValue(item).trim()).filter(Boolean);
}

function normalizedStatus(value: unknown): BuildStatus {
  const status = stringValue(value, "pending").toLowerCase();
  return status === "building" ||
    status === "success" ||
    status === "warning" ||
    status === "error"
    ? status
    : "pending";
}

function normalizeSteps(value: unknown): BuildStep[] {
  if (!Array.isArray(value)) return [];
  return value.filter(isRecord).map((item) => ({
    name: stringValue(item.name, "Unknown step"),
    status: normalizedStatus(item.status),
    message: item.message == null ? null : stringValue(item.message),
    progress_percent: numberValue(item.progress_percent),
    started_at: item.started_at == null ? null : stringValue(item.started_at),
    finished_at: item.finished_at == null ? null : stringValue(item.finished_at),
    duration_ms: item.duration_ms == null ? null : numberValue(item.duration_ms),
  }));
}

function normalizeFeatureChecks(value: unknown): FeatureCheck[] {
  if (!Array.isArray(value)) return [];
  return value.filter(isRecord).map((item) => ({
    key: stringValue(item.key, "feature"),
    title: stringValue(item.title, "機能確認"),
    status: stringValue(item.status, "pending"),
    summary: item.summary == null ? null : stringValue(item.summary),
    checks: Array.isArray(item.checks)
      ? item.checks.filter(isRecord).map((check) => ({
          name: stringValue(check.name, "確認項目"),
          status: stringValue(check.status, "pending"),
          message: check.message == null ? null : stringValue(check.message),
        }))
      : [],
  }));
}

function normalizeGeneration(value: unknown): GeneratedFileSummary[] {
  if (!Array.isArray(value)) return [];
  return value.filter(isRecord).map((item) => ({
    path: stringValue(item.path, "unknown"),
    status: normalizedStatus(item.status),
    source: item.source == null ? null : stringValue(item.source),
    error: item.error == null ? null : stringValue(item.error),
    characters: numberValue(item.characters),
  }));
}

function normalizeIssue(value: unknown): ValidationIssue | null {
  if (!isRecord(value)) return null;
  return {
    level: stringValue(value.level),
    code: stringValue(value.code, "VALIDATION"),
    message: stringValue(value.message, "検証エラーです。"),
    file_path: value.file_path == null ? null : stringValue(value.file_path),
  };
}

function normalizeValidation(value: unknown): ValidationResult | null {
  if (!isRecord(value)) return null;
  return {
    success: typeof value.success === "boolean" ? value.success : undefined,
    status: normalizedStatus(value.status ?? (value.success ? "success" : "error")),
    message: stringValue(value.message),
    checked_files: numberValue(value.checked_files),
    errors: Array.isArray(value.errors)
      ? value.errors.map(normalizeIssue).filter((item): item is ValidationIssue => item !== null)
      : [],
    warnings: Array.isArray(value.warnings)
      ? value.warnings.map(normalizeIssue).filter((item): item is ValidationIssue => item !== null)
      : [],
    logs: stringArray(value.logs),
  };
}

function normalizeRepair(value: unknown): RepairResult | null {
  if (!isRecord(value)) return null;
  const iterations = Array.isArray(value.iterations)
    ? value.iterations.filter(isRecord).map((item) => ({
        iteration: numberValue(item.iteration),
        repaired_files: stringArray(item.repaired_files),
        failed_files: stringArray(item.failed_files),
      }))
    : [];
  return {
    success: typeof value.success === "boolean" ? value.success : undefined,
    total_iterations: numberValue(value.total_iterations, iterations.length),
    iterations,
    final_validation: normalizeValidation(value.final_validation),
    error: value.error == null ? null : stringValue(value.error),
  };
}

/** Normalize current, legacy, and ToolResult-wrapped payloads into one UI model. */
export function normalizeProjectBuildData(value: unknown): ProjectBuildData {
  let source: UnknownRecord = isRecord(value) ? value : {};
  if (!source.project_name && isRecord(source.data)) source = source.data;
  return {
    project_name: stringValue(source.project_name, "generated-app"),
    status: normalizedStatus(source.status),
    message: stringValue(source.message, "プロジェクト生成結果を表示しています。"),
    files_generated: numberValue(source.files_generated),
    project_root: source.project_root == null ? null : stringValue(source.project_root),
    zip_path: source.zip_path == null ? null : stringValue(source.zip_path),
    zip_download_url:
      source.zip_download_url == null ? null : stringValue(source.zip_download_url),
    zip_files_added: numberValue(source.zip_files_added),
    plan: isRecord(source.plan) ? source.plan : null,
    generation: normalizeGeneration(source.generation),
    write_result: isRecord(source.write_result) ? source.write_result : null,
    validation: normalizeValidation(source.validation),
    repair: normalizeRepair(source.repair),
    steps: normalizeSteps(source.steps),
    logs: stringArray(source.logs),
    errors: stringArray(source.errors),
    warnings: stringArray(source.warnings),
    progress_percent: numberValue(source.progress_percent),
    current_stage: stringValue(source.current_stage, "準備中"),
    elapsed_seconds: numberValue(source.elapsed_seconds),
    estimated_total_minutes:
      source.estimated_total_minutes == null ? null : numberValue(source.estimated_total_minutes),
    estimated_remaining_minutes:
      source.estimated_remaining_minutes == null
        ? null
        : numberValue(source.estimated_remaining_minutes),
    estimate_confidence: stringValue(source.estimate_confidence, "low"),
    feature_checks: normalizeFeatureChecks(source.feature_checks),
  };
}

/** Allow only same-app relative URLs and explicit HTTP(S) endpoints. */
export function resolveProjectDownloadUrl(
  value: unknown,
  apiBaseUrl?: string,
): string | null {
  const url = stringValue(value).trim();
  if (!url || /[\u0000-\u001f\u007f\\]/.test(url)) return null;
  if (/^https?:\/\//i.test(url)) {
    // Do not use the global URL constructor here. Some legacy tsconfig files
    // omit the DOM library even though the component is compiled as TSX.
    return /^https?:\/\/[^\s/?#]+(?:[/?#][^\s]*)?$/i.test(url) ? url : null;
  }
  if (/^[a-z][a-z\d+.-]*:/i.test(url) || url.startsWith("//")) return null;
  const relative = url.startsWith("/") ? url : `/${url}`;
  const base = stringValue(apiBaseUrl).trim().replace(/\/$/, "");
  if (!base) return relative;
  if (!/^https?:\/\//i.test(base)) return null;
  return `${base}${relative}`;
}

function statusColors(statusValue: unknown): { color: string; background: string } {
  const status = normalizedStatus(statusValue);
  if (status === "success") return { color: COLORS.success, background: COLORS.successSoft };
  if (status === "warning") return { color: COLORS.warning, background: COLORS.warningSoft };
  if (status === "error") return { color: COLORS.error, background: COLORS.errorSoft };
  if (status === "building") return { color: COLORS.building, background: COLORS.buildingSoft };
  return { color: COLORS.pending, background: COLORS.pendingSoft };
}

function StatusBadge({ status }: { status: unknown }): React.ReactElement {
  const normalized = normalizedStatus(status);
  const colors = statusColors(normalized);
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 10px",
        borderRadius: 999,
        color: colors.color,
        background: colors.background,
        fontSize: 12,
        fontWeight: 750,
        whiteSpace: "nowrap",
      }}
      role="status"
    >
      <span aria-hidden="true">{STATUS_ICONS[normalized]}</span>
      {STATUS_LABELS[normalized]}
    </span>
  );
}

function NoticeList({
  title,
  values,
  tone,
}: {
  title: string;
  values: string[];
  tone: "error" | "warning";
}): React.ReactElement | null {
  if (!values.length) return null;
  const colors = statusColors(tone);
  return (
    <section style={styles.section} aria-label={title}>
      <h4 style={styles.sectionTitle}>{title}</h4>
      <div style={{ ...styles.notice, color: colors.color, background: colors.background }}>
        <ul style={styles.list}>
          {values.map((value, index) => (
            <li key={`${value}-${index}`}>{value}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function issueText(issue: ValidationIssue): string {
  const location = issue.file_path ? ` [${issue.file_path}]` : "";
  return `${issue.code || "VALIDATION"}: ${issue.message || "検証エラーです。"}${location}`;
}

function featureStatus(status: string): BuildStatus {
  const value = status.toLowerCase();
  if (value === "checking") return "building";
  if (value === "planned" || value === "not_verified") return "pending";
  return normalizedStatus(value);
}

function featureStatusLabel(status: string): string {
  const value = status.toLowerCase();
  if (value === "checking") return "確認中";
  if (value === "planned") return "実装予定";
  if (value === "not_verified") return "未確認";
  return STATUS_LABELS[normalizedStatus(value)];
}

function formatElapsed(seconds: number): string {
  if (seconds < 60) return `${seconds.toFixed(seconds < 10 ? 1 : 0)}秒`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes}分${Math.round(seconds % 60)}秒`;
}

export function ProjectBuildBlock({
  data,
  block,
  apiBaseUrl,
  className,
  onDownload,
}: ProjectBuildBlockProps): React.ReactElement {
  const instanceId = React.useId();
  const stepsHeadingId = `${instanceId}-steps`;
  const build = React.useMemo(
    () => normalizeProjectBuildData(data ?? block?.data),
    [data, block?.data],
  );
  const status = normalizedStatus(build.status);
  const colors = statusColors(status);
  const completedSteps = build.steps.filter((step) =>
    ["success", "warning", "error"].includes(normalizedStatus(step.status)),
  ).length;
  const calculatedProgress = build.steps.length
    ? Math.round((completedSteps / build.steps.length) * 100)
    : status === "building"
      ? 10
      : 0;
  const progress = Math.min(
    100,
    status === "success" ? 100 : build.progress_percent || calculatedProgress,
  );
  const downloadUrl = resolveProjectDownloadUrl(build.zip_download_url, apiBaseUrl);
  const validationErrors = (build.validation?.errors ?? []).map(issueText);
  const validationWarnings = (build.validation?.warnings ?? []).map(issueText);
  const repairedFiles = build.repair?.iterations?.flatMap((item) => item.repaired_files ?? []) ?? [];

  return (
    <article
      className={className}
      style={{ ...styles.root, borderTop: `4px solid ${colors.color}` }}
      aria-label={`${build.project_name} のプロジェクト生成結果`}
      aria-busy={status === "building"}
    >
      <header style={styles.header}>
        <div style={styles.titleGroup}>
          <p style={styles.eyebrow}>Project Build</p>
          <h3 style={styles.title}>{build.project_name}</h3>
          <p style={styles.message} aria-live="polite">
            {build.message}
          </p>
        </div>
        <StatusBadge status={status} />
      </header>

      <div style={styles.body}>
        <div
          style={styles.progressTrack}
          role="progressbar"
          aria-label="プロジェクト生成の進捗"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={progress}
        >
          <div
            style={{
              width: `${progress}%`,
              height: "100%",
              borderRadius: 999,
              background: colors.color,
              transition: "width 240ms ease",
            }}
          />
        </div>

        <p style={{ ...styles.message, marginTop: 10 }} aria-live="polite">
          現在の工程: <strong>{build.current_stage}</strong>
          {build.estimated_remaining_minutes != null && status !== "success"
            ? ` ／ 完成までの推定 約${build.estimated_remaining_minutes}分`
            : ""}
          {build.estimate_confidence
            ? `（見積もり精度: ${
                ESTIMATE_CONFIDENCE_LABELS[build.estimate_confidence] ||
                build.estimate_confidence
              }）`
            : ""}
        </p>

        <div style={styles.summaryGrid}>
          <div style={styles.summaryCard}>
            <span style={styles.summaryLabel}>生成ファイル</span>
            <strong style={styles.summaryValue}>{build.files_generated}</strong>
          </div>
          <div style={styles.summaryCard}>
            <span style={styles.summaryLabel}>検証ファイル</span>
            <strong style={styles.summaryValue}>{build.validation?.checked_files ?? 0}</strong>
          </div>
          <div style={styles.summaryCard}>
            <span style={styles.summaryLabel}>自動修復</span>
            <strong style={styles.summaryValue}>{build.repair?.total_iterations ?? 0}回</strong>
          </div>
          <div style={styles.summaryCard}>
            <span style={styles.summaryLabel}>進捗</span>
            <strong style={styles.summaryValue}>{progress}%</strong>
          </div>
          <div style={styles.summaryCard}>
            <span style={styles.summaryLabel}>経過時間</span>
            <strong style={styles.summaryValue}>{formatElapsed(build.elapsed_seconds)}</strong>
          </div>
          <div style={styles.summaryCard}>
            <span style={styles.summaryLabel}>ZIP内ファイル</span>
            <strong style={styles.summaryValue}>{build.zip_files_added ?? 0}</strong>
          </div>
        </div>

        {build.feature_checks.length > 0 && (
          <section style={styles.section} aria-label="機能別の確認状況">
            <h4 style={styles.sectionTitle}>機能別の確認状況</h4>
            <div style={{ display: "grid", gap: 10 }}>
              {build.feature_checks.map((feature, index) => {
                const tone = featureStatus(feature.status);
                const featureColors = statusColors(tone);
                return (
                  <div
                    key={`${feature.key}-${index}`}
                    style={{
                      padding: "12px 14px",
                      border: `1px solid ${COLORS.border}`,
                      borderLeft: `4px solid ${featureColors.color}`,
                      borderRadius: 10,
                      background: featureColors.background,
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                      <strong>{feature.title}</strong>
                      <span
                        style={{ color: featureColors.color, fontSize: 12, fontWeight: 750 }}
                      >
                        {featureStatusLabel(feature.status)}
                      </span>
                    </div>
                    {feature.summary && <p style={styles.stepMessage}>{feature.summary}</p>}
                    {feature.checks.length > 0 && (
                      <ul style={{ ...styles.list, marginTop: 8 }}>
                        {feature.checks.map((check, checkIndex) => (
                          <li key={`${check.name}-${checkIndex}`}>
                            <strong>{featureStatusLabel(check.status)}</strong> — {check.name}
                            {check.message ? `: ${check.message}` : ""}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {build.steps.length > 0 && (
          <section style={styles.section} aria-labelledby={stepsHeadingId}>
            <h4 id={stepsHeadingId} style={styles.sectionTitle}>
              生成工程
            </h4>
            <ol style={styles.stepList}>
              {build.steps.map((step, index) => {
                const stepStatus = normalizedStatus(step.status);
                const stepColors = statusColors(stepStatus);
                return (
                  <li key={`${step.name}-${index}`} style={styles.step}>
                    <span
                      aria-hidden="true"
                      style={{
                        display: "grid",
                        width: 26,
                        height: 26,
                        placeItems: "center",
                        borderRadius: 999,
                        color: stepColors.color,
                        background: stepColors.background,
                        fontWeight: 800,
                      }}
                    >
                      {STATUS_ICONS[stepStatus]}
                    </span>
                    <div>
                      <div style={styles.stepName}>{step.name}</div>
                      {step.message && <div style={styles.stepMessage}>{step.message}</div>}
                    </div>
                  </li>
                );
              })}
            </ol>
          </section>
        )}

        <NoticeList title="エラー" values={[...build.errors, ...validationErrors]} tone="error" />
        <NoticeList
          title="警告"
          values={[...build.warnings, ...validationWarnings]}
          tone="warning"
        />

        {build.generation.length > 0 && (
          <details style={styles.details}>
            <summary style={styles.detailsSummary}>
              生成ファイル一覧（{build.generation.length}）
            </summary>
            <div style={styles.detailsBody}>
              <ul style={styles.list}>
                {build.generation.map((file, index) => (
                  <li key={`${file.path}-${index}`}>
                    <code>{file.path}</code> — {STATUS_LABELS[normalizedStatus(file.status)]}
                    {file.source ? ` / ${file.source}` : ""}
                    {file.error ? ` / ${file.error}` : ""}
                  </li>
                ))}
              </ul>
            </div>
          </details>
        )}

        {build.repair && (
          <details style={styles.details}>
            <summary style={styles.detailsSummary}>
              自動修復結果（{build.repair.total_iterations ?? 0}回）
            </summary>
            <div style={styles.detailsBody}>
              {repairedFiles.length ? (
                <ul style={styles.list}>
                  {repairedFiles.map((path, index) => (
                    <li key={`${path}-${index}`}>
                      <code>{path}</code>
                    </li>
                  ))}
                </ul>
              ) : (
                <p style={styles.message}>修復されたファイルはありません。</p>
              )}
              {build.repair.error && (
                <p style={{ ...styles.notice, ...statusColors("error"), marginTop: 10 }}>
                  {build.repair.error}
                </p>
              )}
            </div>
          </details>
        )}

        {build.logs.length > 0 && (
          <details style={styles.details}>
            <summary style={styles.detailsSummary}>ビルドログ（{build.logs.length}）</summary>
            <div style={styles.detailsBody}>
              <pre style={styles.codeList}>{build.logs.join("\n")}</pre>
            </div>
          </details>
        )}

        {status === "success" && downloadUrl && (
          <section style={{ ...styles.section, display: "flex", justifyContent: "flex-end" }}>
            <a
              href={downloadUrl}
              download={`${build.project_name}.zip`}
              style={styles.download}
              onClick={() => onDownload?.(downloadUrl, build)}
            >
              <span aria-hidden="true">↓</span>
              ZIPをダウンロード
            </a>
          </section>
        )}

        {status === "success" && !downloadUrl && (
          <p style={{ ...styles.notice, ...statusColors("warning"), marginTop: 18 }}>
            生成は完了しましたが、ダウンロードURLがありません。
          </p>
        )}
      </div>
    </article>
  );
}

export default ProjectBuildBlock;
