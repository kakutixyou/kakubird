/// <reference types="vite/client" />

import * as React from "react";
import { Component, Suspense, lazy } from "react";

/** Backendから受け取る1個の表示ブロック。 */
export interface ChatBlock {
  type: string;
  data?: unknown;
  props?: Record<string, unknown> | null;
  id?: string | number | null;
  [key: string]: unknown;
}

export interface BlockComponentProps {
  block: ChatBlock;
  data?: unknown;
  apiBaseUrl?: string;
  onOptionSelect?: (...args: unknown[]) => void;
  onOpenManualEdit?: (...args: unknown[]) => void;
  [key: string]: unknown;
}

export type BlockComponent = React.ComponentType<BlockComponentProps>;
export type BlockRendererRegistry = Record<string, BlockComponent>;

export interface RenderBlocksProps {
  blocks?: unknown;
  apiBaseUrl?: string;
  /** 呼び出し元固有のRenderer。自動登録済みRendererへ追加されます。 */
  renderers?: BlockRendererRegistry;
  onOptionSelect?: (...args: unknown[]) => void;
  onOpenManualEdit?: (...args: unknown[]) => void;
  fallback?: React.ReactNode | ((block: ChatBlock) => React.ReactNode);
}

type ImportedBlockModule = {
  default?: React.ComponentType<any>;
  [exportName: string]: unknown;
};

type BlockImporter = () => Promise<ImportedBlockModule>;

interface BlockErrorBoundaryProps {
  blockType?: string;
  resetKey: React.Key;
  children: React.ReactNode;
}

interface BlockErrorBoundaryState {
  error: Error | null;
}

/**
 * ブロックコンポーネントの自動レジストリ。
 *
 * 対象:
 * - components/blocks直下の.jsx/.tsx
 * - TekiseiTestなど、配下フォルダの.jsx/.tsx
 *
 * index自身と旧BlockRendererは登録対象から除外します。
 */
const modules = import.meta.glob<ImportedBlockModule>([
  "./**/*.jsx",
  "./**/*.tsx",
  "!./index.jsx",
  "!./index.tsx",
  "!./BlockRenderer.jsx",
  "!./BlockRenderer.tsx",
]) as Record<string, BlockImporter>;

export const BLOCK_COMPONENTS: BlockRendererRegistry = {};

export function normalizeBlockType(value: unknown): string {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_");
}

function getComponentName(path: string): string {
  const fileName = path.split("/").pop() ?? "";
  return fileName.replace(/\.(jsx|tsx)$/i, "");
}

function createLazyComponent(
  componentName: string,
  importer: BlockImporter,
): BlockComponent {
  return lazy(async () => {
    const loadedModule = await importer();
    const namedExport = loadedModule[componentName];
    const component =
      loadedModule.default ??
      (typeof namedExport === "function" ? namedExport : undefined);

    if (!component) {
      throw new Error(
        `${componentName} にdefault export、または同名のnamed exportがありません。`,
      );
    }

    return {
      default: component as React.ComponentType<BlockComponentProps>,
    };
  });
}

// ファイル名をブロックコンポーネント名として自動登録します。
Object.entries(modules).forEach(([path, importer]) => {
  const componentName = getComponentName(path);
  if (!componentName) return;

  if (BLOCK_COMPONENTS[componentName]) {
    console.warn(
      `[blocks/index] 同名ブロックを検出しました: ${componentName} (${path})`,
    );
    return;
  }

  BLOCK_COMPONENTS[componentName] = createLazyComponent(
    componentName,
    importer,
  );
});

/**
 * Backendのtype名と実際のコンポーネントファイル名の差を吸収します。
 * 値は実在するコンポーネント名です。
 */
const BLOCK_ALIASES: Record<string, string> = {
  // 万能コード表示ブロックへ統合する名前
  phppreviewblock: "CodeFormatBlock",
  sqlpreviewblock: "CodeFormatBlock",
  htmlcsspreviewblock: "CodeFormatBlock",
  jsonviewerblock: "CodeFormatBlock",
  codeblock: "CodeFormatBlock",
  sqlexamplemodal: "CodeFormatBlock",

  // 既存Backendとの互換名
  githubrepolist: "GithubRepoListBlock",
  githubrepolistblock: "GithubRepoListBlock",
  heroblock: "HeroBlock",
  databaseschema: "DatabaseSchemaBlock",
  databaseschemablock: "DatabaseSchemaBlock",
  filedownload: "FileDownloadBlock",

  // JSON変換ブロックの名前揺れ
  conversionjson: "ConversionJsonBlock",
  conversion_json: "conversion_jsonBlock",

  // ProjectBuilderHandlerが返すブロック
  project_build: "ProjectBuildBlock",
  "project-build": "ProjectBuildBlock",
  projectbuild: "ProjectBuildBlock",
  projectbuildblock: "ProjectBuildBlock",
};

function buildCaseInsensitiveIndex(
  registry: BlockRendererRegistry,
): BlockRendererRegistry {
  return Object.keys(registry).reduce<BlockRendererRegistry>((result, name) => {
    result[name.toLowerCase()] = registry[name];
    return result;
  }, {});
}

function applyAliases(registry: BlockRendererRegistry): BlockRendererRegistry {
  const result: BlockRendererRegistry = { ...registry };
  const caseInsensitive = buildCaseInsensitiveIndex(result);

  Object.entries(BLOCK_ALIASES).forEach(([alias, target]) => {
    const TargetComponent =
      result[target] ?? caseInsensitive[target.toLowerCase()];
    if (TargetComponent) {
      result[alias] = TargetComponent;
    }
  });

  return result;
}

/** 組み込みRendererと呼び出し元固有Rendererを安全に統合します。 */
export function createBlockRenderers(
  existing: BlockRendererRegistry = {},
): BlockRendererRegistry {
  // existingを後に置き、呼び出し元が明示したRendererを優先します。
  return applyAliases({ ...BLOCK_COMPONENTS, ...existing });
}

/**
 * ブロック名からコンポーネントを取得します。
 * 完全一致、正規化名、別名、大文字小文字無視の順で探します。
 */
export function getBlockComponent(
  type: unknown,
  registry: BlockRendererRegistry = createBlockRenderers(),
): BlockComponent | null {
  if (typeof type !== "string") return null;

  const exact = type.trim();
  const normalized = normalizeBlockType(type);
  if (!exact || !normalized) return null;

  const caseInsensitive = buildCaseInsensitiveIndex(registry);
  const aliasTarget = BLOCK_ALIASES[normalized];

  return (
    registry[exact] ??
    registry[normalized] ??
    (aliasTarget
      ? registry[aliasTarget] ?? caseInsensitive[aliasTarget.toLowerCase()]
      : undefined) ??
    caseInsensitive[exact.toLowerCase()] ??
    caseInsensitive[normalized] ??
    null
  );
}

function UnknownBlock({ block }: { block: ChatBlock }): React.ReactElement {
  return (
    <div
      role="note"
      className="rounded border border-slate-400 bg-slate-100 p-3 text-xs text-slate-700 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300"
    >
      未対応の表示ブロックです: <code>{block.type || "type未指定"}</code>
    </div>
  );
}

function BlockLoading(): React.ReactElement {
  return (
    <div
      className="h-12 w-full animate-pulse rounded bg-slate-200/60 dark:bg-slate-700/50"
      aria-label="ブロックを読み込み中"
    />
  );
}

class BlockErrorBoundary extends Component<
  BlockErrorBoundaryProps,
  BlockErrorBoundaryState
> {
  state: BlockErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: unknown): BlockErrorBoundaryState {
    return {
      error: error instanceof Error ? error : new Error(String(error)),
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    console.error(
      `[RenderBlocks] ${this.props.blockType || "unknown"} の描画に失敗しました`,
      error,
      errorInfo,
    );
  }

  componentDidUpdate(previousProps: BlockErrorBoundaryProps): void {
    if (
      this.state.error &&
      previousProps.resetKey !== this.props.resetKey
    ) {
      // 別ブロックへ切り替わったときだけエラー状態を解除します。
      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({ error: null });
    }
  }

  render(): React.ReactNode {
    if (this.state.error) {
      return (
        <div
          role="alert"
          className="rounded border border-amber-700 bg-amber-950/30 p-3 text-xs text-amber-200"
        >
          <div className="font-semibold">
            {this.props.blockType || "ブロック"} の表示に失敗しました。
          </div>
          <div className="mt-1 break-words opacity-80">
            {this.state.error.message}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function isChatBlock(value: unknown): value is ChatBlock {
  return (
    typeof value === "object" &&
    value !== null &&
    !Array.isArray(value) &&
    typeof (value as { type?: unknown }).type === "string"
  );
}

function renderFallback(
  fallback: RenderBlocksProps["fallback"],
  block: ChatBlock,
): React.ReactNode {
  if (typeof fallback === "function") return fallback(block);
  if (fallback !== undefined) return fallback;
  return <UnknownBlock block={block} />;
}

/** Backendから受け取ったblocks配列をまとめて描画します。 */
export function RenderBlocks({
  blocks,
  apiBaseUrl,
  renderers,
  onOptionSelect,
  onOpenManualEdit,
  fallback,
}: RenderBlocksProps): React.ReactElement | null {
  if (!Array.isArray(blocks) || blocks.length === 0) return null;

  const registry = createBlockRenderers(renderers);

  return (
    <div className="ai-custom-blocks-container my-3 w-full space-y-4">
      {blocks.map((candidate, index) => {
        if (!isChatBlock(candidate)) {
          const invalidBlock: ChatBlock = { type: "不正なブロックデータ" };
          return (
            <React.Fragment key={`invalid-block-${index}`}>
              {renderFallback(fallback, invalidBlock)}
            </React.Fragment>
          );
        }

        const block = candidate;
        const blockType = block.type.trim();
        const BlockComponent = getBlockComponent(blockType, registry);
        const blockProps =
          block.props && typeof block.props === "object" && !Array.isArray(block.props)
            ? block.props
            : {};
        const blockKey = block.id ?? `${blockType || "unknown"}-${index}`;

        if (!BlockComponent) {
          console.warn(
            `[RenderBlocks] 未対応のブロックタイプです: ${blockType || "type未指定"}`,
          );
          return (
            <React.Fragment key={blockKey}>
              {renderFallback(fallback, block)}
            </React.Fragment>
          );
        }

        return (
          <div key={blockKey} className="w-full animate-fade-in">
            <BlockErrorBoundary blockType={blockType} resetKey={blockKey}>
              <Suspense fallback={<BlockLoading />}>
                <BlockComponent
                  {...blockProps}
                  block={block}
                  data={block.data ?? blockProps.data}
                  apiBaseUrl={apiBaseUrl}
                  onOptionSelect={onOptionSelect}
                  onOpenManualEdit={onOpenManualEdit}
                />
              </Suspense>
            </BlockErrorBoundary>
          </div>
        );
      })}
    </div>
  );
}

export default RenderBlocks;
